# 0.1.0

* Fixed some typos on the Readme file.
* Fixed a missing image on the Readme file.
* Added missing documentation to the C# project.
* Now the AddBurstedAssembly method returns true, this is a breaking change but no mods are depending on Bursts of Rain at this point in time.

# 0.0.1

* Initial Release